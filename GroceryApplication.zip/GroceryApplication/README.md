# GroceryApplication
My Name is Tarachand Mahto.
This Project Is a part of Virtual Internship - Android Application Development Using Kotlin.

As we can't remember everything, users frequently forget to buy the things they want to buy. However, with the assistance of this app, you can make a list of the groceries you intend to buy so that you don't forget anything.

